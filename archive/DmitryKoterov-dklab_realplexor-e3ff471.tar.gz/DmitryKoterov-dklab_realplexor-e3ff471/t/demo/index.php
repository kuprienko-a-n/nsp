<html>

<frameset rows="70%,*">
  <frame src="fr_ids.php?<?=$_SERVER['QUERY_STRING']?>" />
  <frame src="fr_form.php?<?=$_SERVER['QUERY_STRING']?>" />
</frameset>
      
</html>
