API implementation for various languages.
